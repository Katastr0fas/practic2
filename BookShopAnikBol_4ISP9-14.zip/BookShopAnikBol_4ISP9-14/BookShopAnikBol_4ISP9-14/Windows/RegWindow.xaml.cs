﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BookShopAnikBol_4ISP9_14.Class;
using BookShopAnikBol_4ISP9_14.DB;

namespace BookShopAnikBol_4ISP9_14.Windows
{
    /// <summary>
    /// Логика взаимодействия для RegWindow.xaml
    /// </summary>
    public partial class RegWindow : Window
    {
        private Client EditClient;
        private bool isEdit = false;
        public RegWindow()
        {
            InitializeComponent();
            CMBGender.ItemsSource = EFClass.Context.Gender.ToList();
            CMBGender.DisplayMemberPath = "Name";
            CMBGender.SelectedIndex = 0;
        }


        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TbLName.Text) || string.IsNullOrWhiteSpace(TbFName.Text) || string.IsNullOrWhiteSpace(TbPhone.Text) || (string.IsNullOrWhiteSpace(TbEmail.Text) || string.IsNullOrWhiteSpace(TbLogin.Text) || string.IsNullOrWhiteSpace(TbPassword.Text) || CMBGender.SelectedItem is null))

            {
                MessageBox.Show("Некорректно заполненные данные");
                return;
            }
            else
            {
                //try
                // {
                Client client = new DB.Client();
                client.LastName = TbLName.Text;
                client.FirstName = TbFName.Text;
                client.Email = TbEmail.Text;
                client.Phone = TbPhone.Text;
                client.Login = TbLogin.Text;
                client.idGender = (CMBGender.SelectedItem as Gender).id;
                client.Password = TbPassword.Text;
                EFClass.Context.Client.Add(client);
                EFClass.Context.SaveChanges();
                MessageBox.Show("Всё гуд!");
            }
            // catch (Exception ex)
            // {
            //     MessageBox.Show(ex.Message);
            // }


            // }
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            TestWindow auth = new TestWindow();
            auth.Show();
            Close();
        }

    }
}
