﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BookShopAnikBol_4ISP9_14.Class.EFClass;
using static BookShopAnikBol_4ISP9_14.Class.BasketClass;
using BookShopAnikBol_4ISP9_14.DB;

namespace BookShopAnikBol_4ISP9_14.Windows

{
    /// <summary>
    /// Логика взаимодействия для BasketWindow.xaml
    /// </summary>
    public partial class BasketWindow : Window
    {
        public BasketWindow()
        {
            InitializeComponent();

            GetListProduct();
        }

        private void GetListProduct()
        {

            ObservableCollection<DB.Order> orders = new ObservableCollection<DB.Order>(Class.BasketClass.order);
            LVBasket.ItemsSource = orders;
            decimal price = 0;
            foreach (var item in orders)
            {
                price += Convert.ToDecimal(item.Quantity * item.Cost); 
            }
            tbAllCost.Text = price.ToString();
        }
        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button == null)
            {
                return;
            }

            DB.Order selectedOrder = button.DataContext as DB.Order;
            if (selectedOrder != null)
            {
                selectedOrder.Quantity++;
                int o = order.IndexOf(selectedOrder);
                order.Remove(selectedOrder);
                order.Insert(o, selectedOrder);
            }
            GetListProduct();
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            ObservableCollection<DB.Order> orders = new ObservableCollection<DB.Order>(Class.BasketClass.order);
            if (order.Count() == 0)
            {
                MessageBox.Show("Корзина пуста");
            }
            else
            {
                
                MessageBox.Show("Продукты успешно добавлены");
            }
            Close();
        }

        private void BtnRemoveToCart_Click_1(object sender, RoutedEventArgs e)
        {

            Button button = sender as Button;
            if (button == null)
            {
                return;
            }

            DB.Order selectedOrders = button.DataContext as DB.Order;

            if (selectedOrders != null)
            {
                if (selectedOrders.Quantity == 1 || selectedOrders.Quantity == 0)
                {
                    Class.BasketClass.order.Remove(selectedOrders);
                }
                else
                {
                    selectedOrders.Quantity--;
                    int o = Class.BasketClass.order.IndexOf(selectedOrders);
                    Class.BasketClass.order.Remove(selectedOrders);
                    Class.BasketClass.order.Insert(o, selectedOrders);
                }

            }
            
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            BooksWindow books = new BooksWindow();
            books.Show();
            this.Close();
        }
    }
}
