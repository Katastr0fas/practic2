﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using BookShopAnikBol_4ISP9_14.DB;
using static Microsoft.Win32.OpenFileDialog;
using Microsoft.Win32;
using BookShopAnikBol_4ISP9_14.Class;
using static BookShopAnikBol_4ISP9_14.Class.EFClass;
using System.Runtime.Remoting.Contexts;


namespace BookShopAnikBol_4ISP9_14.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public AddWindow()
        {
            InitializeComponent();
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Books books = new Books();
            books.Name = TbName.Text;
            books.Cost = Convert.ToDecimal(TbCost.Text);

            EFClass.Context.Books.Add(books);
           EFClass.Context.SaveChanges();
            MessageBox.Show("Добавление прошло успешно");
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            BooksWindow books = new BooksWindow();
            books.Show();
            this.Close();
        }
    }
}

    