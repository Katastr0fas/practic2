﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BookShopAnikBol_4ISP9_14.Windows;

namespace BookShopAnikBol_4ISP9_14.Windows
{
    /// <summary>
    /// Логика взаимодействия для TestWindow.xaml
    /// </summary>
    public partial class TestWindow : Window
    {
        public TestWindow()
        {
            InitializeComponent();
        }
        private void btnRegIn_Click(object sender, RoutedEventArgs e)
        {
            RegWindow reg = new RegWindow();
            reg.Show();
            this.Close();
        }

        private void btnLogIn_Click(object sender, RoutedEventArgs e)
        {
            var AuthUser = Class.EFClass.Context.Client.ToList()
          .Where(i => i.Login == txtLogin.Text && i.Password == txtPassword.Text).FirstOrDefault();
            if (AuthUser != null)
            {
                Class.UserClass.User = AuthUser;
                BooksWindow books = new BooksWindow();
                books.Show();
                Close();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }

        private void txtLogin_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtLogin.Text == "" || txtLogin.Text == "Логин") txtLogin.Text = "";
        }

        private void txtLogin_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtLogin.Text == "") txtLogin.Text = "Логин";
        }

        private void txtPassword_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtPassword.Text == "" || txtPassword.Text == "Пароль") txtPassword.Text = "";
        }

        private void txtPassword_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtPassword.Text == "") txtPassword.Text = "Пароль";
        }
    }
}



