﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShopAnikBol_4ISP9_14.Class
{
    internal class BasketClass
    {
        public static List<DB.Order> order { get; set; } = new List<DB.Order>();
        public static List<DB.Books> books { get; set; } = new List<DB.Books>();
    }
}
