﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookShopAnikBol_4ISP9_14.DB;

namespace BookShopAnikBol_4ISP9_14.Class
{
    internal class UserClass
    {
        public static Client User { get; set; }
        public static Books Books { get; set; } 
    }
}
