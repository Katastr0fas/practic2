﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BookShopAnikBol_4ISP9_14.Class;
using BookShopAnikBol_4ISP9_14.DB;
using BookShopAnikBol_4ISP9_14.Windows;

namespace BookShopAnikBol_4ISP9_14.Windows
{
    /// <summary>
    /// Логика взаимодействия для BooksWindow.xaml
    /// </summary>
    public partial class BooksWindow : Window
    {
        public BooksWindow()
        {
            InitializeComponent();

            List<Books> books  = new List<Books>();

            books = EFClass.Context.Books.ToList();

            LVProdList.ItemsSource = books;
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            AddWindow addWindow = new AddWindow();
            addWindow.Show();
            this.Close();

        }

        private void btnBasket_Click(object sender, RoutedEventArgs e)
        {
            BasketWindow basketWindow = new BasketWindow();
            basketWindow.ShowDialog();
            this.Hide();
        }

        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            bool seek = true;
            Button button = sender as Button;
            if (button == null)
            {
                return;
            }
            DB.Order selectedOrder = button.DataContext as DB.Order;
            if (selectedOrder != null)
            {
                for (int i = 0; i < Class.BasketClass.order.Count; i++)
                {
                    if (Class.BasketClass.order[i] == selectedOrder)
                    {
                        Class.BasketClass.order[i].Quantity++;
                        seek = false;
                    }
                }
                if (seek)
                {
                    selectedOrder.Quantity = 1;
                    Class.BasketClass.order.Add(selectedOrder);
                }
            }
        }

        
    }
}
