﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookShopAnikBol_4ISP9_14.DB;

namespace BookShopAnikBol_4ISP9_14.Class
{
    internal class EFClass
    {
        public static Entities Context { get; set; } = new Entities();

    }
}
